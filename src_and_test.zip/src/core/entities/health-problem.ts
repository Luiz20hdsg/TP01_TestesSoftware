export type HealthProblem = {
  name: string;
  degree: number;
};
